-- Verificando o MD5 da senha padrão '123456' com o sufixo '_mysalt'
SELECT DISTINCT(md5('123456_mysalt')) FROM employee;

-- Criando coluna de senha na tabela employee com senha padrão md5('123456_mysalt')
ALTER TABLE employee
    ADD COLUMN pwd CHAR(32) DEFAULT '20192768934332241ccbe0731328d89a';

SELECT * FROM employee;

-- Criando employee 123123123 com senha 321321
INSERT INTO EMPLOYEE VALUES ('James'     , 'E'         , 'Borg'      , '123123123', '1927-11-27', '450 Stone, Houston, TX'          , 'M'       , 55000        , null            , 1, md5('321321_mysalt'));

SELECT * FROM employee WHERE ssn = '123123123';

-- Verificando senha
SELECT pwd=md5('321321_mysalt') AS result FROM employee WHERE ssn = '123123123';
SELECT pwd=md5('123123_mysalt') AS result FROM employee WHERE ssn = '123123123';

DELETE FROM employee WHERE ssn = '123123123';

-- Removendo a coluna de senha da tabela employee
ALTER TABLE employee DROP COLUMN pwd;

