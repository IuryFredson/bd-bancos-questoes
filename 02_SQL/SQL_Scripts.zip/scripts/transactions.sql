-- --------------------
-- Setting auto commit
-- --------------------

SELECT @@AUTOCOMMIT;

SET AUTOCOMMIT=0;

-- ----------------------------------------
-- Demonstrating ISOLATION of transactions
-- ----------------------------------------

-- SESSION 1
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
UPDATE EMPLOYEE SET salary = 100000 WHERE fname='John';
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';

-- SESSION 2
-- Open new connection and execute
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';

-- SESSION 1
COMMIT;

-- SESSION 2
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';

-- -----------------------------------------------
-- Demonstrating DURATION lasts only after commit
-- -----------------------------------------------

SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
UPDATE EMPLOYEE SET salary = 200000 WHERE fname='John';
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';

-- Kill Application and start again

SET AUTOCOMMIT=0;
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
UPDATE EMPLOYEE SET salary = 200000 WHERE fname='John';
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';

-- Kill Application and start again
SET AUTOCOMMIT=0;
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
COMMIT;

-- -----------------------
-- Demonstrating ROLLBACK
-- -----------------------

UPDATE EMPLOYEE SET salary = 300000 WHERE fname='John';
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
ROLLBACK;
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
COMMIT;

-- -----------------------------------------------------
-- HOW TO USE SET TRANSACTION (READ WRITE vs READ ONLY)
-- -----------------------------------------------------

SET TRANSACTION READ ONLY;
START TRANSACTION;
UPDATE EMPLOYEE SET salary = 300000 WHERE fname='John';
COMMIT;
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
COMMIT;

SET TRANSACTION READ WRITE;
START TRANSACTION;
UPDATE EMPLOYEE SET salary = 300000 WHERE fname='John';
COMMIT;
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
COMMIT;

-- -----------------------------------------------------
-- HOW TO USE SET TRANSACTION ISOLATION LEVEL
-- -----------------------------------------------------

-- SESSION 1
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
UPDATE EMPLOYEE SET salary = 400000 WHERE fname='John';
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';

-- SESSION 2
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
START TRANSACTION;
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
COMMIT;

-- SESSION 2
START TRANSACTION;
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
COMMIT;

-- SESSION 2
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
START TRANSACTION;
SELECT fname, lname, salary FROM EMPLOYEE  WHERE fname='John';
-- This will hold until you COMMIT; on session 1
COMMIT;


