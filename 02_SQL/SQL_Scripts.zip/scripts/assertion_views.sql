-- ------------------------------------
-- A1
-- ------------------------------------

DELIMITER $$
CREATE TRIGGER SALARY_T
    BEFORE INSERT ON EMPLOYEE 
    FOR EACH ROW
    BEGIN
    IF NEW.salary > (SELECT salary FROM EMPLOYEE WHERE ssn=NEW.super_ssn) THEN
        SET NEW.salary = 0;
    END IF;
    END$$
DELIMITER ;

SELECT ssn, fname, lname, salary FROM EMPLOYEE;

INSERT INTO employee VALUES ('Marcel', 'V', 'Oliveira',
        '000555000', '1977-09-13', '13 Basket Street, Natal, RN', 'M', 60000, '888665555', '1') ;

SELECT ssn, fname, lname, salary FROM EMPLOYEE;

DELETE FROM employee WHERE ssn='000555000';

SHOW TRIGGERS;

DROP TRIGGER SALARY_T;

-- ------------------------------------
-- V1
-- ------------------------------------
CREATE VIEW WORKS_ON_NEW AS
    SELECT FNAME, LNAME, PNAME, HOURS
        FROM EMPLOYEE, PROJECT, WORKS_ON
    WHERE SSN=ESSN AND PNO=PNUMBER;

SELECT * FROM WORKS_ON_NEW;

-- ------------------------------------
-- V2
-- ------------------------------------
CREATE VIEW DEPTS_INFO(dept_name, no_of_emps, total_sal)
AS SELECT dname, COUNT(*), SUM(salary)
   FROM DEPARTMENT, EMPLOYEE
   WHERE dnumber=dno
   GROUP BY dname;

SELECT * FROM DEPTS_INFO;

SELECT dept_name FROM DEPTS_INFO where no_of_emps > 10;

-- Acrescentando um funcionário no departamento de Hardware
INSERT INTO employee VALUES ('Marcel', 'V', 'Oliveira',
        '000555000', '1977-09-13', '13 Basket Street, Natal, RN', 'M', 10000, '888665555', '7') ;

SELECT dept_name FROM DEPTS_INFO where no_of_emps > 10;

DELETE FROM employee where ssn='000555000';

SELECT dept_name FROM DEPTS_INFO where no_of_emps > 10;

DROP VIEW DEPTS_INFO;
