-- ------------------------------------
-- Password: root
-- ------------------------------------

-- ------------------------------------
-- Cria��o, exibi��o e remo��o de esquemas
-- ------------------------------------

CREATE DATABASE COMPANY;
SHOW DATABASES;
DROP DATABASE COMPANY;
SHOW DATABASES;

CREATE DATABASE COMPANY;

-- ------------------------------------
-- Sele��o de esquemas
-- ------------------------------------

USE COMPANY;

-- ------------------------------------
-- Confirma��o de sele��o
-- ------------------------------------

SELECT DATABASE();

