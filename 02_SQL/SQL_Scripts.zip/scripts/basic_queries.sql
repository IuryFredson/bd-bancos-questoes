-- ------------------------------------
-- Q0
-- ------------------------------------
SELECT  BDATE, ADDRESS
FROM EMPLOYEE
WHERE FNAME='John' AND MINIT='B' AND LNAME='Smith';

-- ------------------------------------
-- Q1
-- ------------------------------------
SELECT FNAME, LNAME, ADDRESS
FROM EMPLOYEE, DEPARTMENT
WHERE DNAME='Research' AND DNUMBER=DNO;

-- ------------------------------------
-- Q2
-- ------------------------------------
SELECT PNUMBER,DNUM,LNAME, BDATE,ADDRESS 
FROM PROJECT, DEPARTMENT, EMPLOYEE
WHERE DNUM=DNUMBER 
        AND MGR_SSN=SSN
        AND PLOCATION='Stafford';

-- ------------------------------------
-- Q8
-- ------------------------------------
SELECT E.FNAME, E.LNAME, S.FNAME, S.LNAME
FROM EMPLOYEE E, EMPLOYEE S 
WHERE E.SUPER_SSN=S.SSN;

-- ------------------------------------
-- Q1A
-- ------------------------------------
SELECT E.FNAME, E.LNAME, E.ADDRESS
FROM EMPLOYEE E, DEPARTMENT D
WHERE D.DNAME='Research' AND D.DNUMBER=E.DNO;

-- ------------------------------------
-- Q9
-- ------------------------------------
SELECT SSN FROM EMPLOYEE;

-- ------------------------------------
-- Q9
-- ------------------------------------
SELECT  SSN, DNAME FROM EMPLOYEE, DEPARTMENT;

-- ------------------------------------
-- Q1C
-- ------------------------------------
SELECT  *
FROM EMPLOYEE
WHERE DNO=5;

-- ------------------------------------
-- Q1D
-- ------------------------------------
SELECT *
FROM EMPLOYEE, DEPARTMENT
WHERE dname='Research' AND dno=dnumber;

-- ------------------------------------
-- Q10A
-- ------------------------------------
SELECT *
FROM EMPLOYEE, DEPARTMENT;

-- ------------------------------------
-- Q11
-- ------------------------------------
(SELECT ALL SALARY FROM EMPLOYEE);

-- ------------------------------------
-- Q11A
-- ------------------------------------
SELECT DISTINCT SALARY FROM EMPLOYEE;

-- ------------------------------------
-- Q4
-- ------------------------------------
(SELECT PNUMBER FROM PROJECT, DEPARTMENT, EMPLOYEE
 WHERE DNUM=DNUMBER AND MGR_SSN=SSN AND LNAME='Smith')
UNION  
(SELECT PNUMBER FROM PROJECT, WORKS_ON, EMPLOYEE
 WHERE PNUMBER=PNO AND ESSN=SSN AND LNAME='Smith');

-- ------------------------------------
-- Q12
-- ------------------------------------
SELECT FNAME, LNAME, ADDRESS 
FROM EMPLOYEE 
WHERE address LIKE '%Houston,%TX%';

-- ------------------------------------
-- Q12A
-- ------------------------------------
SELECT FNAME, LNAME, BDATE 
FROM EMPLOYEE 
WHERE bdate LIKE '195_______';

SELECT FNAME, LNAME, DATE_FORMAT(bdate, '%d-%m-%y') 
FROM EMPLOYEE 
WHERE bdate LIKE '195_______';

SELECT FNAME, LNAME, DATE_FORMAT(bdate, '%D-%M-%Y') 
FROM EMPLOYEE 
WHERE bdate LIKE '195_______';

-- ------------------------------------
-- Q13
-- ------------------------------------
SELECT fname, lname, salary AS old_salary, 1.1*salary AS increased_salary 
FROM EMPLOYEE, WORKS_ON, PROJECT 
WHERE ssn=essn AND pno=pnumber AND pname='ProductX';

-- ------------------------------------
-- Q14
-- ------------------------------------
SELECT fname, lname FROM EMPLOYEE
WHERE 
	(salary BETWEEN 30000 AND 40000)
	AND dno=5;

-- ------------------------------------
-- Q15
-- ------------------------------------
SELECT dname, lname, fname, pname 
FROM DEPARTMENT, EMPLOYEE, WORKS_ON, PROJECT
WHERE dnumber=dno AND ssn=essn AND pno=pnumber
ORDER BY dname, lname, fname;

SELECT dname, lname, fname, pname 
FROM DEPARTMENT, EMPLOYEE, WORKS_ON, PROJECT
WHERE dnumber=dno AND ssn=essn AND pno=pnumber
ORDER BY dname DESC, lname ASC, fname ASC;

-- ------------------------------------
-- Q18
-- ------------------------------------
SELECT fname, lname 
FROM EMPLOYEE 
WHERE super_ssn IS NULL;

-- ------------------------------------
-- Q4A
-- ------------------------------------
SELECT DISTINCT pnumber
FROM PROJECT
WHERE pnumber IN
        (SELECT pnumber
         FROM PROJECT, DEPARTMENT, EMPLOYEE
         WHERE DNUM=DNUMBER 
             AND MGR_SSN=SSN 
             AND LNAME='Smith')
    OR pnumber IN
        (SELECT pno 
         FROM WORKS_ON, EMPLOYEE
         WHERE ESSN=SSN 
            AND LNAME='Smith');

-- ------------------------------------
-- QX1
-- ------------------------------------
SELECT DISTINCT essn
FROM WORKS_ON
WHERE (pno,hours) 
IN (SELECT pno, hours
    FROM WORKS_ON
    WHERE essn='123456789');

-- ------------------------------------
-- QX2
-- ------------------------------------
SELECT lname, fname
FROM EMPLOYEE
WHERE salary > ALL (SELECT salary
                    FROM EMPLOYEE
                    WHERE dno='5');
                    
-- ------------------------------------
-- Q16
-- ------------------------------------
SELECT E.FNAME, E.LNAME
FROM EMPLOYEE AS E
WHERE E.SSN IN
    (SELECT essn 
     FROM DEPENDENT
     WHERE E.ssn = essn AND E.FNAME=DEPENDENT_NAME AND E.sex=sex);
         
-- ------------------------------------
-- Q16A
-- ------------------------------------
SELECT E.FNAME, E.LNAME
FROM EMPLOYEE AS E, DEPENDENT AS D
WHERE E.SSN=D.essn 
      AND E.FNAME=D.DEPENDENT_NAME   
      AND E.sex=D.sex;                    
      
-- ------------------------------------
-- Q16B
-- ------------------------------------
SELECT E.FNAME, E.LNAME
FROM EMPLOYEE AS E
WHERE EXISTS 
    (SELECT * 
     FROM DEPENDENT 
     WHERE E.SSN=essn 
            AND E.FNAME=DEPENDENT_NAME   
            AND E.sex=sex);

-- ------------------------------------
-- Q6
-- ------------------------------------
SELECT  FNAME, LNAME
FROM    EMPLOYEE
WHERE   NOT EXISTS   
    (SELECT    *
     FROM DEPENDENT
     WHERE SSN=ESSN);

-- ------------------------------------
-- Q7
-- ------------------------------------
SELECT FNAME, LNAME
FROM EMPLOYEE
WHERE 
    EXISTS   
    (SELECT * FROM DEPENDENT WHERE SSN=ESSN)
    AND
    EXISTS   
    (SELECT * FROM DEPARTMENT WHERE SSN=MGR_SSN);

-- ------------------------------------
-- Q3
-- ------------------------------------
SELECT FNAME, LNAME 
FROM EMPLOYEE
WHERE 
    NOT EXISTS   
    ( (SELECT * FROM WORKS_ON W1 
       WHERE (W1.pno IN 
                (SELECT pnumber 
			     FROM PROJECT 
                 WHERE dnum=5))
             AND
             NOT EXISTS (SELECT *
                         FROM WORKS_ON W2
                         WHERE W2.essn=ssn 
                            AND W1.pno=W2.pno) ) );

-- ------------------------------------
-- Q17
-- ------------------------------------
SELECT DISTINCT ESSN
FROM WORKS_ON
WHERE PNO IN (1, 2, 3);

-- ------------------------------------
-- Q8A
-- ------------------------------------
SELECT E.lname AS Employee_name, S.lname AS Supervisor_name
FROM EMPLOYEE AS E, EMPLOYEE AS S
WHERE E.super_ssn=s.ssn;

-- ------------------------------------
-- Q1A
-- ------------------------------------
SELECT fname, lname, address
FROM EMPLOYEE JOIN DEPARTMENT ON dno=dnumber
WHERE dname='Research';

-- ------------------------------------
-- Q1A EXPLAIN
-- ------------------------------------

EXPLAIN
SELECT FNAME, LNAME, ADDRESS
FROM EMPLOYEE, DEPARTMENT
WHERE DNAME='Research' AND DNUMBER=DNO;

EXPLAIN
SELECT FNAME, LNAME, ADDRESS
FROM EMPLOYEE JOIN DEPARTMENT ON DNUMBER=DNO
WHERE DNAME='Research';

-- ------------------------------------
-- Q3 STATS
-- ------------------------------------

SELECT FNAME, LNAME 
FROM EMPLOYEE
WHERE 
    NOT EXISTS   
    ( (SELECT * FROM WORKS_ON W1 
       WHERE (W1.pno IN 
                (SELECT pnumber 
			     FROM PROJECT 
                 WHERE dnum=5))
             AND
             NOT EXISTS (SELECT *
                         FROM WORKS_ON W2
                         WHERE W2.essn=ssn 
                            AND W1.pno=W2.pno) ) );


-- ------------------------------------
-- Q1B
-- ------------------------------------
SELECT fname, lname, address
FROM 
    EMPLOYEE NATURAL JOIN 
    (SELECT dname, 
			dnumber AS dno,
            mgr_ssn AS mssn,
            mgr_start_date AS msdate
       FROM DEPARTMENT) AS DEPTO
WHERE dname='Research';

SELECT dno, dnumber
FROM EMPLOYEE NATURAL JOIN  DEPARTMENT;

-- ------------------------------------
-- Q8B
-- ------------------------------------
-- Q8A:
SELECT E.lname AS Employee_name,          
        S.lname AS Supervisor_name
FROM EMPLOYEE AS E, EMPLOYEE AS S
WHERE E.super_ssn=s.ssn;

-- Q8B:
SELECT E.lname AS Employee_name,          
        S.lname AS Supervisor_name
FROM (EMPLOYEE AS E LEFT OUTER JOIN EMPLOYEE AS S
        ON E.super_ssn=S.ssn);

-- ------------------------------------
-- Q2A
-- ------------------------------------
SELECT PNUMBER,DNUM,LNAME,BDATE, ADDRESS 
FROM ((PROJECT JOIN DEPARTMENT ON DNUM=DNUMBER) 
      JOIN EMPLOYEE ON MGR_SSN=SSN)
WHERE PLOCATION='Stafford';

-- ------------------------------------
-- Q19
-- ------------------------------------
SELECT SUM(salary), MAX(salary), MIN(salary), AVG(Salary)
FROM EMPLOYEE;

-- ------------------------------------
-- Q20
-- ------------------------------------
SELECT SUM(salary), MAX(salary), MIN(salary), AVG(Salary)
FROM (EMPLOYEE JOIN DEPARTMENT ON dno=dnumber)
WHERE dname='Research';

SELECT fname, SUM(salary)
FROM (EMPLOYEE JOIN DEPARTMENT ON dno=dnumber)
WHERE dname='Research';

-- ------------------------------------
-- Q21
-- ------------------------------------
SELECT COUNT(*) FROM EMPLOYEE;

-- ------------------------------------
-- Q22
-- ------------------------------------
SELECT COUNT(*) 
FROM EMPLOYEE, DEPARTMENT
WHERE dno=dnumber AND dname='Research';

-- ------------------------------------
-- Q23
-- ------------------------------------
SELECT COUNT(DISTINCT SALARY) 
FROM EMPLOYEE;

-- ------------------------------------
-- Q5
-- ------------------------------------
SELECT lname, fname
FROM EMPLOYEE
WHERE (SELECT COUNT(*) FROM DEPENDENT WHERE ssn=essn) > 1;

-- ------------------------------------
-- Q24
-- ------------------------------------
SELECT dno, COUNT(*) AS num_employee, AVG(salary) as avg_salary
FROM EMPLOYEE
GROUP BY dno;

-- ------------------------------------
-- Q25
-- ------------------------------------
SELECT PNUMBER, PNAME, COUNT(*)
FROM PROJECT, WORKS_ON
WHERE PNUMBER=PNO
GROUP BY PNUMBER, PNAME;

SELECT PNAME, PLOCATION, COUNT(*)
FROM PROJECT, WORKS_ON
WHERE PNUMBER=PNO
GROUP BY PLOCATION;

-- ------------------------------------
-- Q26
-- ------------------------------------
SELECT PNUMBER, PNAME, COUNT(*)
FROM PROJECT, WORKS_ON
WHERE PNUMBER=PNO
GROUP BY PNUMBER, PNAME
HAVING COUNT(*) > 2;

-- ------------------------------------
-- Q27
-- ------------------------------------
SELECT PNUMBER, PNAME, COUNT(*)
FROM PROJECT, WORKS_ON, EMPLOYEE
WHERE PNUMBER=PNO AND SSN=ESSN AND DNO=5
GROUP BY PNUMBER, PNAME;

-- ------------------------------------
-- Q3Op
-- ------------------------------------
SELECT fname, lname
FROM (works_on JOIN employee ON essn=ssn)
WHERE pno IN			
	(SELECT pnumber
   FROM project
   WHERE dnum=5)
GROUP BY essn
HAVING COUNT(DISTINCT pno) =	
    (SELECT COUNT(*)              			 
     FROM project     
	 WHERE dnum=5);

-- ------------------------------------
-- Q28
-- ------------------------------------
SELECT DNAME, COUNT(*)
FROM DEPARTMENT, EMPLOYEE
WHERE dnumber=dno AND salary>40000
GROUP BY dname
HAVING COUNT(*) > 5;

SELECT DNAME, COUNT(*)
FROM DEPARTMENT, EMPLOYEE
WHERE dnumber=dno AND salary>40000
    AND dno IN (SELECT dno 
                FROM EMPLOYEE
                GROUP BY dno
                HAVING COUNT(*) > 5)
GROUP BY dnumber;

-- ------------------------------------
-- Q29
-- ------------------------------------

WITH RECURSIVE hierarchy (ssn, fname, super_ssn, depth)
AS ( -- Base case: Bob
     SELECT e.ssn, e.fname, e.super_ssn, 0 AS depth
     FROM employee e
     WHERE e.fname = 'Bob'

     UNION ALL

     -- Recursive step: everyone that is already 
     --                 supervised by someone in the set
     SELECT e2.ssn, e2.fname, e2.super_ssn, s.depth + 1
     FROM employee e2 
          JOIN hierarchy s ON e2.super_ssn = s.ssn )

SELECT ssn, fname, super_ssn, depth
FROM hierarchy
ORDER BY depth, fname; 
