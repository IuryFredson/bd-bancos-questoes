-- ------------------------------------
-- U1
-- ------------------------------------
INSERT INTO EMPLOYEE
VALUES ('Richard','K','Marini', '653298653', '1952-12-30',
        '98 Oak Forest, Katy, TX', 'M', 37000, '987654321', '4');

SELECT * FROM EMPLOYEE WHERE ssn='653298653';
DELETE FROM EMPLOYEE WHERE ssn='653298653';

-- ------------------------------------
-- U1A
-- ------------------------------------
INSERT INTO EMPLOYEE(fname,lname,dno,ssn)
VALUES ('Richard','Marini','4','653298653');

SELECT * FROM EMPLOYEE WHERE ssn='653298653';

-- ------------------------------------
-- U2
-- ------------------------------------
INSERT INTO EMPLOYEE(fname,lname,ssn,dno)
VALUES ('Robert','Hatcher','980760540','2');

DELETE FROM EMPLOYEE WHERE ssn='980760540';

INSERT INTO EMPLOYEE(fname,lname,dno)
VALUES ('Robert','Hatcher','2');

INSERT INTO EMPLOYEE(fname,lname,ssn,dno)
VALUES ('Robert','Hatcher','980760540','2');

-- ------------------------------------
-- U3A
-- ------------------------------------
CREATE TABLE DEPTS_INFO
    (dept_name VARCHAR(15), 
     no_of_emps INTEGER, 
     total_sal INTEGER);

INSERT INTO DEPTS_INFO(dept_name, no_of_emps, total_sal)
    (SELECT  dname, COUNT(*), SUM(salary)
    FROM (DEPARTMENT JOIN EMPLOYEE ON dnumber=dno)
    GROUP BY DNAME);

SELECT * FROM DEPTS_INFO; 

SELECT dept_name FROM DEPTS_INFO where no_of_emps > 10;

-- Acrescentando um funcionário no departamento de Hardware
INSERT INTO employee VALUES ('Marcel', 'V', 'Oliveira',
        '000555000', '1977-09-13', '13 Basket Street, Natal, RN', 'M', 10000, '888665555', '7') ;

SELECT dept_name FROM DEPTS_INFO where no_of_emps > 10;

DELETE FROM employee where ssn='000555000';
DROP TABLE DEPTS_INFO;

-- ------------------------------------
-- U4A
-- ------------------------------------
SELECT fname, lname FROM EMPLOYEE;

DELETE FROM EMPLOYEE
WHERE lname='Brown';

-- ------------------------------------
-- U4B
-- ------------------------------------
SELECT ssn, fname, lname, dependent_name
FROM EMPLOYEE JOIN DEPENDENT ON ssn=essn
WHERE ssn='123456789';

SELECT ssn, fname, lname, pname
FROM ((EMPLOYEE JOIN WORKS_ON ON ssn=essn) 
        JOIN PROJECT ON pnumber=pno)
WHERE ssn='123456789';

DELETE FROM EMPLOYEE
WHERE SSN='123456789';

SELECT fname, lname FROM EMPLOYEE;
SELECT * FROM DEPENDENT;
SELECT * FROM WORKS_ON;
SELECT * FROM PROJECT;

-- ------------------------------------
-- U4C
-- ------------------------------------
SELECT ssn, fname, lname
FROM (EMPLOYEE JOIN DEPARTMENT ON dno=dnumber) 
WHERE dname='Research';

DELETE FROM EMPLOYEE
WHERE dno IN
    (SELECT DNUMBER
     FROM DEPARTMENT
     WHERE DNAME='Research');

SELECT fname, lname, super_ssn FROM EMPLOYEE;
SELECT * FROM DEPARTMENT;
SELECT * FROM WORKS_ON;
SELECT * FROM DEPENDENT;

-- ------------------------------------
-- U4C
-- ------------------------------------
DELETE FROM EMPLOYEE;

SELECT fname, lname, super_ssn FROM EMPLOYEE;
SELECT * FROM DEPARTMENT;
SELECT * FROM WORKS_ON;
SELECT * FROM DEPENDENT;

-- ------------------------------------
-- U5
-- ------------------------------------
SELECT * FROM PROJECT;

UPDATE PROJECT
SET PLOCATION = 'Bellaire', DNUM = 5
WHERE PNUMBER=10;

SELECT * FROM PROJECT;

-- ------------------------------------
-- U6
-- ------------------------------------
SELECT ssn, fname, lname, salary 
FROM (EMPLOYEE JOIN DEPARTMENT ON dno=dnumber) 
WHERE dname='Research';

UPDATE EMPLOYEE
SET salary = salary*1.1
WHERE dno IN 
    (SELECT dnumber 
     FROM DEPARTMENT
     WHERE dname='Research');

SELECT ssn, fname, lname, salary 
FROM (EMPLOYEE JOIN DEPARTMENT ON dno=dnumber) 
WHERE dname='Research';

