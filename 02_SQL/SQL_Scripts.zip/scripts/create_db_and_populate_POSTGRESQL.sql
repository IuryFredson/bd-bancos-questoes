CREATE DOMAIN SSN_TYPE AS CHAR(9);
CREATE DOMAIN TINY_TEXT AS VARCHAR(8);
CREATE DOMAIN SMALL_TEXT AS VARCHAR(15);
CREATE DOMAIN LARGE_TEXT AS VARCHAR(50);

CREATE TABLE employee(
    fname     SMALL_TEXT     NOT NULL,
    minit     CHAR,
    lname     SMALL_TEXT     NOT NULL,
    ssn       SSN_TYPE         NOT NULL,
    bdate     DATE,
    address   LARGE_TEXT,
    sex       CHAR,
    salary    DECIMAL(10,2),
    super_ssn SSN_TYPE,
    dno       INT             NOT NULL DEFAULT 1,
    CONSTRAINT EMPPK
        PRIMARY KEY(ssn),
    CONSTRAINT EMPSUPERFK
        FOREIGN KEY(super_ssn)
        REFERENCES employee(ssn)
        ON DELETE SET NULL
);

CREATE TABLE department(
    dname             SMALL_TEXT NOT NULL,
    dnumber           INT         NOT NULL CHECK (dnumber > 0 AND dnumber < 21),
    mgr_ssn           SSN_TYPE,
    mgr_start_date    DATE,
    CONSTRAINT DEPTPK
        PRIMARY KEY(dnumber),
    CONSTRAINT DEPTSK
        UNIQUE(dname),
    CONSTRAINT DEPTMGRFK
        FOREIGN KEY(mgr_ssn) REFERENCES employee(ssn)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

CREATE TABLE dept_locations(
    dnumber     INT         NOT NULL,
    dlocation   SMALL_TEXT NOT NULL,
    PRIMARY KEY(dnumber,dlocation),
    FOREIGN KEY (dnumber) REFERENCES department(dnumber)
);

CREATE TABLE project(
    pname     VARCHAR(30) NOT NULL,
    pnumber   INT NOT NULL,
    plocation SMALL_TEXT ,
    dnum INT NOT NULL,
    PRIMARY KEY(pnumber),
    UNIQUE(pname),
    FOREIGN KEY (dnum) REFERENCES department(dnumber)
);

CREATE TABLE works_on(
    essn  SSN_TYPE NOT NULL,
    pno   INT     NOT NULL,
    hours DECIMAL(3,1),
    PRIMARY KEY(essn,pno),
    CONSTRAINT EMPFK
        FOREIGN KEY(essn) REFERENCES employee(ssn)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT PROJFK
        FOREIGN KEY(pno) REFERENCES project(pnumber)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE TABLE dependent(
    essn            SSN_TYPE     NOT NULL,
    dependent_name  SMALL_TEXT NOT NULL,
    sex             CHAR,
    bdate           DATE,
    relationship    TINY_TEXT,
    PRIMARY KEY(essn,dependent_name),
    CONSTRAINT EMP_DEP_FK
        FOREIGN KEY(essn) REFERENCES employee(ssn)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

ALTER TABLE employee 
      ADD CONSTRAINT FOREIGN_DNO
      FOREIGN KEY(dno)
      REFERENCES DEPARTMENT(dnumber);

DELETE FROM DEPARTMENT WHERE true;
INSERT INTO DEPARTMENT VALUES ('Research'      , 5             , NULL   , '1978-05-22');
INSERT INTO DEPARTMENT VALUES ('Administration', 4             , NULL   , '1985-01-01');
INSERT INTO DEPARTMENT VALUES ('Headquarters'  , 1             , NULL   , '1971-06-19');
INSERT INTO DEPARTMENT VALUES ('Software'      , 6             , NULL   , '1999-05-15');
INSERT INTO DEPARTMENT VALUES ('Hardware'      , 7             , NULL   , '1998-05-15');
INSERT INTO DEPARTMENT VALUES ('Sales'         , 8             , NULL   , '1997-01-01');

DELETE FROM EMPLOYEE WHERE true;
INSERT INTO EMPLOYEE VALUES ('James'     , 'E'         , 'Borg'      , '888665555', '1927-11-27', '450 Stone, Houston, TX'          , 'M'       , 55000        , null            , 1);
INSERT INTO EMPLOYEE VALUES ('Franklin'  , 'T'         , 'Wong'      , '333445555', '1945-12-08', '638 Voss, Houston, TX'           , 'M'       , 40000        , '888665555'     , 5);
INSERT INTO EMPLOYEE VALUES ('Jennifer'  , 'S'         , 'Wallace'   , '987654321', '1931-06-20', '291 Berry, Bellaire, TX'         , 'F'       , 43000        , '888665555'     , 4);
INSERT INTO EMPLOYEE VALUES ('John'      , 'B'         , 'Smith'     , '123456789', '1955-01-09', '731 Fondren, Houston, TX'        , 'M'       , 30000        , '333445555'     , 5);
INSERT INTO EMPLOYEE VALUES ('Alicia'    , 'J'         , 'Zelaya'    , '999887777', '1958-07-19', '3321 Castle, Spring, TX'         , 'F'       , 25000        , '987654321'     , 4);
INSERT INTO EMPLOYEE VALUES ('Ramesh'    , 'K'         , 'Narayan'   , '666884444', '1952-09-15', '971 Fire Oak, Humble, TX'        , 'M'       , 38000        , '333445555'     , 5);
INSERT INTO EMPLOYEE VALUES ('Joyce'     , 'A'         , 'English'   , '453453453', '1962-07-31', '5631 Rice, Houston, TX'          , 'F'       , 25000        , '333445555'     , 5);
INSERT INTO EMPLOYEE VALUES ('Ahmad'     , 'V'         , 'Jabbar'    , '987987987', '1959-03-29', '980 Dallas, Houston, TX'         , 'M'       , 25000        , '987654321'     , 4);
INSERT INTO EMPLOYEE VALUES ('Jared'     , 'D'         , 'James'     , '111111100', '1966-10-10', '123 Peachtree, Atlanta, GA'      , 'M'       , 85000        , null            , 6);
INSERT INTO EMPLOYEE VALUES ('Alex'      , 'D'         , 'Freed'     , '444444400', '1950-10-09', '4333 Pillsbury, Milwaukee, WI'   , 'M'       , 89000        , null            , 7);
INSERT INTO EMPLOYEE VALUES ('John'      , 'C'         , 'James'     , '555555500', '1975-06-30', '7676 Bloomington, Sacramento, CA', 'M'       , 81000        , null            , 6);
INSERT INTO EMPLOYEE VALUES ('John'      , 'C'         , 'Jones'     , '111111101', '1967-11-14', '111 Allgood, Atlanta, GA'        , 'M'       , 45000        , '111111100'     , 6);
INSERT INTO EMPLOYEE VALUES ('Justin'    , null        , 'Mark'      , '111111102', '1966-01-12', '2342 May, Atlanta, GA'           , 'M'       , 40000        , '111111100'     , 6);
INSERT INTO EMPLOYEE VALUES ('Brad'      , 'C'         , 'Knight'    , '111111103', '1968-02-13', '176 Main St., Atlanta, GA'       , 'M'       , 44000        , '111111100'     , 6);
INSERT INTO EMPLOYEE VALUES ('Evan'      , 'E'         , 'Wallis'    , '222222200', '1958-01-16', '134 Pelham, Milwaukee, WI'       , 'M'       , 92000        , null            , 7);
INSERT INTO EMPLOYEE VALUES ('Josh'      , 'U'         , 'Zell'      , '222222201', '1954-05-22', '266 McGrady, Milwaukee, WI'      , 'M'       , 56000        , '222222200'     , 7);
INSERT INTO EMPLOYEE VALUES ('Andy'      , 'C'         , 'Vile'      , '222222202', '1944-06-21', '1967 Jordan, Milwaukee, WI'      , 'M'       , 53000        , '222222200'     , 7);
INSERT INTO EMPLOYEE VALUES ('Tom'       , 'G'         , 'Brand'     , '222222203', '1966-12-16', '112 Third St, Milwaukee, WI'     , 'M'       , 62500        , '222222200'     , 7);
INSERT INTO EMPLOYEE VALUES ('Jenny'     , 'F'         , 'Vos'       , '222222204', '1967-11-11', '263 Mayberry, Milwaukee, WI'     , 'F'       , 61000        , '222222201'     , 7);
INSERT INTO EMPLOYEE VALUES ('Chris'     , 'A'         , 'Carter'    , '222222205', '1960-03-21', '565 Jordan, Milwaukee, WI'       , 'F'       , 43000        , '222222201'     , 7);
INSERT INTO EMPLOYEE VALUES ('Kim'       , 'C'         , 'Grace'     , '333333300', '1970-10-23', '6677 Mills Ave, Sacramento, CA'  , 'F'       , 79000        , null            , 6);
INSERT INTO EMPLOYEE VALUES ('Jeff'      , 'H'         , 'Chase'     , '333333301', '1970-01-07', '145 Bradbury, Sacramento, CA'    , 'M'       , 44000        , '333333300'     , 6);
INSERT INTO EMPLOYEE VALUES ('Bonnie'    , 'S'         , 'Bays'      , '444444401', '1956-06-19', '111 Hollow, Milwaukee, WI'       , 'F'       , 70000        , '444444400'     , 7);
INSERT INTO EMPLOYEE VALUES ('Alec'      , 'C'         , 'Best'      , '444444402', '1966-06-18', '233 Solid, Milwaukee, WI'        , 'M'       , 60000        , '444444400'     , 7);
INSERT INTO EMPLOYEE VALUES ('Sam'       , 'S'         , 'Snedden'   , '444444403', '1977-07-31', '987 Windy St, Milwaukee, WI'     , 'M'       , 48000        , '444444400'     , 7);
INSERT INTO EMPLOYEE VALUES ('Nandita'   , 'K'         , 'Ball'      , '555555501', '1969-04-16', '222 Howard, Sacramento, CA'      , 'M'       , 62000        , '555555500'     , 6);
INSERT INTO EMPLOYEE VALUES ('Bob'       , 'B'         , 'Bender'    , '666666600', '1968-04-17', '8794 Garfield, Chicago, IL'      , 'M'       , 96000        , null            , 8);
INSERT INTO EMPLOYEE VALUES ('Jill'      , 'J'         , 'Jarvis'    , '666666601', '1966-01-14', '6234 Lincoln, Chicago, IL'       , 'F'       , 36000        , '666666600'     , 8);
INSERT INTO EMPLOYEE VALUES ('Kate'      , 'W'         , 'King'      , '666666602', '1966-04-16', '1976 Boone Trace, Chicago, IL'   , 'F'       , 44000        , '666666600'     , 8);
INSERT INTO EMPLOYEE VALUES ('Lyle'      , 'G'         , 'Leslie'    , '666666603', '1963-06-09', '417 Hancock Ave, Chicago, IL'    , 'M'       , 41000        , '666666601'     , 8);
INSERT INTO EMPLOYEE VALUES ('Billie'    , 'J'         , 'King'      , '666666604', '1960-01-01', '556 Washington, Chicago, IL'     , 'F'       , 38000        , '666666603'     , 8);
INSERT INTO EMPLOYEE VALUES ('Jon'       , 'A'         , 'Kramer'    , '666666605', '1964-08-22', '1988 Windy Creek, Seattle, WA'   , 'M'       , 41500        , '666666603'     , 8);
INSERT INTO EMPLOYEE VALUES ('Ray'       , 'H'         , 'King'      , '666666606', '1949-08-16', '213 Delk Road, Seattle, WA'      , 'M'       , 44500        , '666666604'     , 8);
INSERT INTO EMPLOYEE VALUES ('Gerald'    , 'D'         , 'Small'     , '666666607', '1962-05-15', '122 Ball Street, Dallas, TX'     , 'M'       , 29000        , '666666602'     , 8);
INSERT INTO EMPLOYEE VALUES ('Arnold'    , 'A'         , 'Head'      , '666666608', '1967-05-19', '233 Spring St, Dallas, TX'       , 'M'       , 33000        , '666666602'     , 8);
INSERT INTO EMPLOYEE VALUES ('Helga'     , 'C'         , 'Pataki'    , '666666609', '1969-03-11', '101 Holyoke St, Dallas, TX'      , 'F'       , 32000        , '666666602'     , 8);
INSERT INTO EMPLOYEE VALUES ('Naveen'    , 'B'         , 'Drew'      , '666666610', '1970-05-23', '198 Elm St, Philadelphia, PA'    , 'M'       , 34000        , '666666607'     , 8);
INSERT INTO EMPLOYEE VALUES ('Carl'      , 'E'         , 'Reedy'     , '666666611', '1977-06-21', '213 Ball St, Philadelphia, PA'   , 'M'       , 32000        , '666666610'     , 8);
INSERT INTO EMPLOYEE VALUES ('Sammy'     , 'G'         , 'Hall'      , '666666612', '1970-01-11', '433 Main Street, Miami, FL'      , 'M'       , 37000        , '666666611'     , 8);
INSERT INTO EMPLOYEE VALUES ('Red'       , 'A'         , 'Bacher'    , '666666613', '1980-05-21', '196 Elm Street, Miami, FL'       , 'M'       , 33500        , '666666612'     , 8);

UPDATE department SET mgr_ssn='333445555' WHERE dname='Research';
UPDATE department SET mgr_ssn='987654321' WHERE dname='Administration';
UPDATE department SET mgr_ssn='888665555' WHERE dname='Headquarters';
UPDATE department SET mgr_ssn='111111100' WHERE dname='Software';
UPDATE department SET mgr_ssn='444444400' WHERE dname='Hardware';
UPDATE department SET mgr_ssn='555555500' WHERE dname='Sales';

DELETE FROM DEPT_LOCATIONS WHERE true;
INSERT INTO DEPT_LOCATIONS VALUES (1             , 'Houston');
INSERT INTO DEPT_LOCATIONS VALUES (4             , 'Stafford');
INSERT INTO DEPT_LOCATIONS VALUES (5             , 'Bellaire');
INSERT INTO DEPT_LOCATIONS VALUES (5             , 'Sugarland');
INSERT INTO DEPT_LOCATIONS VALUES (5             , 'Houston');
INSERT INTO DEPT_LOCATIONS VALUES (6             , 'Atlanta');
INSERT INTO DEPT_LOCATIONS VALUES (6             , 'Sacramento');
INSERT INTO DEPT_LOCATIONS VALUES (7             , 'Milwaukee');
INSERT INTO DEPT_LOCATIONS VALUES (8             , 'Chicago');
INSERT INTO DEPT_LOCATIONS VALUES (8             , 'Dallas');
INSERT INTO DEPT_LOCATIONS VALUES (8             , 'Philadephia');
INSERT INTO DEPT_LOCATIONS VALUES (8             , 'Seattle');
INSERT INTO DEPT_LOCATIONS VALUES (8             , 'Miami');

DELETE FROM PROJECT WHERE true;
INSERT INTO PROJECT VALUES ('ProductX'        , 1             , 'Bellaire'      , 5);
INSERT INTO PROJECT VALUES ('ProductY'        , 2             , 'Sugarland'     , 5);
INSERT INTO PROJECT VALUES ('ProductZ'        , 3             , 'Houston'       , 5);
INSERT INTO PROJECT VALUES ('Computerization' , 10            , 'Stafford'      , 4);
INSERT INTO PROJECT VALUES ('Reorganization'  , 20            , 'Houston'       , 1);
INSERT INTO PROJECT VALUES ('Newbenefits'     , 30            , 'Stafford'      , 4);
INSERT INTO PROJECT VALUES ('OperatingSystems', 61            , 'Jacksonville'  , 6);
INSERT INTO PROJECT VALUES ('DatabaseSystems' , 62            , 'Birmingham'    , 6);
INSERT INTO PROJECT VALUES ('Middleware'      , 63            , 'Jackson'       , 6);
INSERT INTO PROJECT VALUES ('InkjetPrinters'  , 91            , 'Phoenix'       , 7);
INSERT INTO PROJECT VALUES ('LaserPrinters'   , 92            , 'LasVegas'      , 7);

DELETE FROM WORKS_ON WHERE true;
INSERT INTO WORKS_ON VALUES ('123456789', 1         , 32.5);
INSERT INTO WORKS_ON VALUES ('123456789', 2         , 7.5);
INSERT INTO WORKS_ON VALUES ('666884444', 3         , 40);
INSERT INTO WORKS_ON VALUES ('453453453', 1         , 20);
INSERT INTO WORKS_ON VALUES ('453453453', 2         , 20);
INSERT INTO WORKS_ON VALUES ('333445555', 2         , 10);
INSERT INTO WORKS_ON VALUES ('333445555', 3         , 10);
INSERT INTO WORKS_ON VALUES ('333445555', 10        , 10);
INSERT INTO WORKS_ON VALUES ('333445555', 20        , 10);
INSERT INTO WORKS_ON VALUES ('999887777', 30        , 30);
INSERT INTO WORKS_ON VALUES ('999887777', 10        , 10);
INSERT INTO WORKS_ON VALUES ('987987987', 10        , 35);
INSERT INTO WORKS_ON VALUES ('987987987', 30        , 5);
INSERT INTO WORKS_ON VALUES ('987654321', 30        , 20);
INSERT INTO WORKS_ON VALUES ('987654321', 20        , 15);
INSERT INTO WORKS_ON VALUES ('888665555', 20        , 0);
INSERT INTO WORKS_ON VALUES ('111111100', 61        , 40);
INSERT INTO WORKS_ON VALUES ('111111101', 61        , 40);
INSERT INTO WORKS_ON VALUES ('111111102', 61        , 40);
INSERT INTO WORKS_ON VALUES ('111111103', 61        , 40);
INSERT INTO WORKS_ON VALUES ('222222200', 62        , 40);
INSERT INTO WORKS_ON VALUES ('222222201', 62        , 48);
INSERT INTO WORKS_ON VALUES ('222222202', 62        , 40);
INSERT INTO WORKS_ON VALUES ('222222203', 62        , 40);
INSERT INTO WORKS_ON VALUES ('222222204', 62        , 40);
INSERT INTO WORKS_ON VALUES ('222222205', 62        , 40);
INSERT INTO WORKS_ON VALUES ('333333300', 63        , 40);
INSERT INTO WORKS_ON VALUES ('333333301', 63        , 46);
INSERT INTO WORKS_ON VALUES ('444444400', 91        , 40);
INSERT INTO WORKS_ON VALUES ('444444401', 91        , 40);
INSERT INTO WORKS_ON VALUES ('444444402', 91        , 40);
INSERT INTO WORKS_ON VALUES ('444444403', 91        , 40);
INSERT INTO WORKS_ON VALUES ('555555500', 92        , 40);
INSERT INTO WORKS_ON VALUES ('555555501', 92        , 44);
INSERT INTO WORKS_ON VALUES ('666666601', 91        , 40);
INSERT INTO WORKS_ON VALUES ('666666603', 91        , 40);
INSERT INTO WORKS_ON VALUES ('666666604', 91        , 40);
INSERT INTO WORKS_ON VALUES ('666666605', 92        , 40);
INSERT INTO WORKS_ON VALUES ('666666606', 91        , 40);
INSERT INTO WORKS_ON VALUES ('666666607', 61        , 40);
INSERT INTO WORKS_ON VALUES ('666666608', 62        , 40);
INSERT INTO WORKS_ON VALUES ('666666609', 63        , 40);
INSERT INTO WORKS_ON VALUES ('666666610', 61        , 40);
INSERT INTO WORKS_ON VALUES ('666666611', 61        , 40);
INSERT INTO WORKS_ON VALUES ('666666612', 61        , 40);
INSERT INTO WORKS_ON VALUES ('666666613', 1         , 5);
INSERT INTO WORKS_ON VALUES ('666666613', 2         , 5);
INSERT INTO WORKS_ON VALUES ('666666613', 3         , 5);
INSERT INTO WORKS_ON VALUES ('666666613', 10        , 5);
INSERT INTO WORKS_ON VALUES ('666666613', 20        , 5);
INSERT INTO WORKS_ON VALUES ('666666613', 30        , 5);
INSERT INTO WORKS_ON VALUES ('666666613', 61        , 30);
INSERT INTO WORKS_ON VALUES ('666666613', 62        , 10);
INSERT INTO WORKS_ON VALUES ('666666613', 63        , 10);
INSERT INTO WORKS_ON VALUES ('666666613', 91        , 5);
INSERT INTO WORKS_ON VALUES ('666666613', 92        , 5);

DELETE FROM DEPENDENT WHERE true;
INSERT INTO DEPENDENT VALUES ('333445555', 'Alice'              , 'F'       , '1976-04-05', 'Daughter');
INSERT INTO DEPENDENT VALUES ('333445555', 'Theodore'           , 'M'       , '1973-10-25', 'Son');
INSERT INTO DEPENDENT VALUES ('333445555', 'Joy'                , 'F'       , '1948-05-03', 'Spouse');
INSERT INTO DEPENDENT VALUES ('987654321', 'Abner'              , 'M'       , '1932-02-29', 'Spouse');
INSERT INTO DEPENDENT VALUES ('123456789', 'Michael'            , 'M'       , '1978-01-01', 'Son');
INSERT INTO DEPENDENT VALUES ('123456789', 'Alice'              , 'F'       , '1978-12-31', 'Daughter');
INSERT INTO DEPENDENT VALUES ('123456789', 'Elizabeth'          , 'F'       , '1957-05-05', 'Spouse');
INSERT INTO DEPENDENT VALUES ('444444400', 'Johnny'             , 'M'       , '1997-04-04', 'Son');
INSERT INTO DEPENDENT VALUES ('444444400', 'Tommy'              , 'M'       , '1999-06-07', 'Son');
INSERT INTO DEPENDENT VALUES ('444444401', 'Chris'              , 'M'       , '1969-04-19', 'Spouse');
INSERT INTO DEPENDENT VALUES ('444444402', 'Alec'               , 'M'       , '1964-02-14', 'Spouse');

