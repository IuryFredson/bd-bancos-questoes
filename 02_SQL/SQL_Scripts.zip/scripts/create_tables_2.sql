DROP DATABASE COMPANY;
CREATE DATABASE COMPANY;
USE COMPANY;

CREATE TABLE employee(
    fname     VARCHAR(15)     NOT NULL,
    minit     CHAR,
    lname     VARCHAR(15)     NOT NULL,
    ssn       CHAR(9)         NOT NULL,
    bdate     DATE,
    address   VARCHAR(50),
    sex       CHAR,
    salary    DECIMAL(10,2),
    super_ssn CHAR(9),
    dno       INT             NOT NULL DEFAULT 1,
    CONSTRAINT EMPPK 
        PRIMARY KEY(ssn),
    CONSTRAINT EMPSUPERFK
        FOREIGN KEY(super_ssn) 
        REFERENCES employee(ssn)
        ON DELETE SET NULL
/* 
        ON UPDATE CASCADE

http://dev.mysql.com/doc/refman/5.0/en/innodb-foreign-key-constraints.html

If ON UPDATE CASCADE or ON UPDATE SET NULL recurses to update the same table 
it has previously updated during the cascade, it acts like RESTRICT. This 
means that you cannot use self-referential ON UPDATE CASCADE or ON UPDATE SET 
NULL operations. This is to prevent infinite loops resulting from cascaded 
updates. A self-referential ON DELETE SET NULL, on the other hand, is 
possible, as is a self-referential ON DELETE CASCADE. Cascading operations 
may not be nested more than 15 levels deep. 

*/
);

SHOW TABLES; 
DESCRIBE employee;

CREATE TABLE department(
    dname             VARCHAR(15) NOT NULL,
    dnumber           INT         NOT NULL CHECK (dnumber > 0 AND dnumber < 21),
    mgr_ssn           CHAR(9),
    mgr_start_date    DATE,
    CONSTRAINT DEPTPK 
        PRIMARY KEY(dnumber),
    CONSTRAINT DEPTSK
        UNIQUE(dname),
    CONSTRAINT DEPTMGRFK
        FOREIGN KEY(mgr_ssn) REFERENCES employee(ssn)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

CREATE TABLE dept_locations(
    dnumber     INT         NOT NULL,
    dlocation   VARCHAR(15) NOT NULL,
    PRIMARY KEY(dnumber,dlocation),
    FOREIGN KEY (dnumber) REFERENCES department(dnumber)
);

CREATE TABLE project(
    pname     VARCHAR(30) NOT NULL,
    pnumber   INT NOT NULL,
    plocation VARCHAR(15) ,
    dnum INT NOT NULL,
    PRIMARY KEY(pnumber),
    UNIQUE(pname),
    FOREIGN KEY (dnum) REFERENCES department(dnumber)
);

CREATE TABLE works_on(
    essn  CHAR(9) NOT NULL,
    pno   INT     NOT NULL,
    hours DECIMAL(3,1),
    PRIMARY KEY(essn,pno),
    CONSTRAINT EMPFK
        FOREIGN KEY(essn) REFERENCES employee(ssn)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT PROJFK
        FOREIGN KEY(pno) REFERENCES project(pnumber)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE TABLE dependent(
    essn            CHAR(9)     NOT NULL,
    dependent_name  VARCHAR(15) NOT NULL,
    sex             CHAR,
    bdate           DATE,
    relationship    VARCHAR(8),
    PRIMARY KEY(essn,dependent_name),
    CONSTRAINT EMP_DEP_FK
        FOREIGN KEY(essn) REFERENCES employee(ssn)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);


