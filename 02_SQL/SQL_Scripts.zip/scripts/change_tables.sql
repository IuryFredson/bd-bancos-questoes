DROP TABLE dependent CASCADE;

CREATE TABLE dependent(
    essn            CHAR(9)     NOT NULL,
    dependent_name  VARCHAR(15) NOT NULL,
    sex             CHAR,
    bdate           DATE,
    relationship    VARCHAR(8),
    PRIMARY KEY(essn,dependent_name),
    FOREIGN KEY(essn) REFERENCES employee(ssn)
);

describe employee;

ALTER TABLE employee
    ADD COLUMN job VARCHAR(12) NOT NULL;

describe employee;

ALTER TABLE employee
    DROP COLUMN job;

ALTER TABLE employee
	DROP CONSTRAINT EMPSUPERFK;
    
ALTER TABLE employee ADD CONSTRAINT 
      FOREIGN KEY(dno)       
      REFERENCES DEPARTMENT(dnumber);
    
ALTER TABLE employee 
    DROP COLUMN job;    

