-- ------------------------------------
-- Cria��o de tabelas
-- ------------------------------------

CREATE TABLE employee(
    fname     VARCHAR(15)     NOT NULL,
    minit     CHAR,
    lname     VARCHAR(15)     NOT NULL,
    ssn       CHAR(9)         NOT NULL,
    bdate     DATE,
    address   VARCHAR(50),
    sex       CHAR,
    salary    DECIMAL(10,2),
    super_ssn CHAR(9),
    dno       INT             NOT NULL,
    PRIMARY KEY(ssn),
    FOREIGN KEY(super_ssn) REFERENCES employee(ssn)
);

SHOW TABLES;
DESCRIBE employee;

CREATE TABLE department(
    dname             VARCHAR(15) NOT NULL,
    dnumber           INT,
    mgr_ssn           CHAR(9)     NOT NULL,
    mgr_start_date    DATE,
    PRIMARY KEY(dnumber),
    UNIQUE(dname),
    FOREIGN KEY (mgr_ssn) REFERENCES employee(ssn)
);

CREATE TABLE dept_locations(
    dnumber     INT         NOT NULL,
    dlocation   VARCHAR(15) NOT NULL,
    PRIMARY KEY(dnumber,dlocation),
    FOREIGN KEY (dnumber) REFERENCES department(dnumber)
);

CREATE TABLE project(
    pname     VARCHAR(30) NOT NULL,
    pnumber   INT NOT NULL,
    plocation VARCHAR(15) ,
    dnum INT NOT NULL,
    PRIMARY KEY(pnumber),
    UNIQUE(pname),
    FOREIGN KEY (dnum) REFERENCES department(dnumber)
);

CREATE TABLE works_on(
    essn  CHAR(9) NOT NULL,
    pno   INT     NOT NULL,
    hours DECIMAL(3,1),
    PRIMARY KEY(essn,pno),
    FOREIGN KEY(essn) REFERENCES employee(ssn),
    FOREIGN KEY(pno)  REFERENCES project(pnumber)
);

CREATE TABLE dependent(
    essn            CHAR(9)     NOT NULL,
    dependent_name  VARCHAR(15) NOT NULL,
    sex             CHAR,
    bdate           DATE,
    relationship    VARCHAR(8),
    PRIMARY KEY(essn,dependent_name),
    FOREIGN KEY(essn) REFERENCES employee(ssn)
);

SHOW TABLES;
DESCRIBE employee;
DROP TABLE EMPLOYEE;


-- 
